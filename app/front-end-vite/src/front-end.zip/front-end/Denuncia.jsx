import { useState } from "react";
import api from "../services/api";

export default function Denuncia() {

  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [local, setLocal] = useState("");
  const [categoria, setCategoria] = useState("");

  async function enviar() {

    try {

      const resposta = await api.post(
        "/denuncias",
        {
          titulo,
          descricao,
          local,
          categoria
        }
      );

      console.log(resposta.data);

      alert("Denúncia enviada!");

    } catch (err) {

      console.error(err);

      alert("Erro ao enviar denúncia");
    }
  }

  return (
    <>
      <input
        placeholder="Título"
        onChange={(e) =>
          setTitulo(e.target.value)
        }
      />

      <input
        placeholder="Local"
        onChange={(e) =>
          setLocal(e.target.value)
        }
      />

      <input
        placeholder="Categoria"
        onChange={(e) =>
          setCategoria(e.target.value)
        }
      />

      <textarea
        placeholder="Descrição"
        onChange={(e) =>
          setDescricao(e.target.value)
        }
      />

      <button onClick={enviar}>
        Enviar denúncia
      </button>
    </>
  );
}